from flask import Flask, request, jsonify, render_template
import re
import random

app = Flask(__name__)


pairs = [

    [r"(?i)hello|hi|hey", [
        "Hello! Welcome to Tech Support Chatbot.",
        "Hi there! How can I help you?",
        "Hey! What issue are you facing?"
    ]],

    [r"(?i)who are you|what is your name", [
        "I am a Tech Support Chatbot.",
        "I help solve technical problems.",
        "Your virtual assistant for tech issues."
    ]],

    [r"(?i).*(slow|lag|hanging).*", [
        "Your system may be slow due to background apps.",
        "Try restarting your system.",
        "Clear temporary files and unused programs.",
        "Upgrade RAM for better performance."
    ]],

    [r"(?i).*(internet|wifi|network).*", [
        "Check your WiFi connection.",
        "Restart your router.",
        "Reconnect to the network.",
        "Try moving closer to the router."
    ]],

    [r"(?i).*(not turning on|won't start|power issue).*", [
        "Check your power cable.",
        "Ensure battery is charged.",
        "Hold power button for 10 seconds."
    ]],

    [r"(?i).*(battery|charging).*", [
        "Check your charger and cable.",
        "Avoid overcharging your battery.",
        "Battery may need replacement."
    ]],

    [r"(?i).*(keyboard|keys not working).*", [
        "Restart your laptop.",
        "Update keyboard drivers.",
        "Try an external keyboard."
    ]],

    [r"(?i).*(mouse|cursor).*", [
        "Check mouse connection.",
        "Replace battery if wireless.",
        "Try another USB port."
    ]],

    [r"(?i).*(screen|display|black screen).*", [
        "Restart your system.",
        "Check display cable.",
        "Update graphics drivers."
    ]],

    [r"(?i).*(install|installation).*", [
        "Download from official website.",
        "Follow installation steps.",
        "Check system requirements."
    ]],

    [r"(?i).*(app crash|application not responding).*", [
        "Restart the application.",
        "Update the software.",
        "Reinstall if problem continues."
    ]],

    [r"(?i).*(virus|malware).*", [
        "Run antivirus scan.",
        "Avoid unknown downloads.",
        "Keep system updated."
    ]],

    [r"(?i).*(storage|disk full|space).*", [
        "Delete unnecessary files.",
        "Empty recycle bin.",
        "Use disk cleanup tool."
    ]],

    [r"(?i).*(file not opening|cannot open file).*", [
        "Check file format.",
        "Use compatible software.",
        "File might be corrupted."
    ]],

    [r"(?i).*(forgot password|password reset).*", [
        "Use 'Forgot Password' option.",
        "Check your email for reset link.",
        "Create a strong new password."
    ]],

    [r"(?i).*(printer|printing).*", [
        "Check printer connection.",
        "Ensure paper and ink are available.",
        "Restart printer."
    ]],

    [r"(?i).*(bluetooth).*", [
        "Turn Bluetooth off and on.",
        "Check device compatibility.",
        "Reconnect the device."
    ]],

    [r"(?i).*(sound|audio).*", [
        "Check volume settings.",
        "Update audio drivers.",
        "Ensure speakers are connected."
    ]],

    [r"(?i).*(python error|code not running|error).*", [
        "Check error message carefully.",
        "Install missing libraries.",
        "Debug step by step."
    ]],

    [r"(?i)thanks|thank you", [
        "You're welcome!",
        "Glad I could help!",
        "Anytime you need assistance!"
    ]],

    [r"(?i)bye|goodbye", [
        "Goodbye! Have a great day.",
        "Bye! Come again.",
        "Take care!"
    ]],
    [r"(?i).*(software|app|application).*(not opening|not launching|crash|not responding).*", [
    "Try running the software as administrator.",
    "Check if the software is properly installed.",
    "Reinstall the application if it still doesn't open."
]],

[r"(?i).*(software|system).*(update failed|update issue).*", [
    "Check your internet connection.",
    "Restart your system and try again.",
    "Ensure enough storage space is available."
]],

[r"(?i).*(software crash|app crash).*(compatibility issue|not compatible).*", [
    "Check system requirements of the software.",
    "Try running in compatibility mode.",
    "Update your operating system."
]],

[r"(?i).*(password|account).*(not working|wrong|reset issue).*", [
    "Make sure Caps Lock is off.",
    "Try resetting your password.",
    "Check for typing mistakes."
]],

[r"(?i).*(reset password|forgot password).*(email not received|not coming).*", [
    "Check your spam/junk folder.",
    "Wait a few minutes and try again.",
    "Ensure you entered the correct email address."
]],

[r"(?i).*(ram|memory).*(high usage|full|low|issue).*", [
    "Close unused applications.",
    "Check Task Manager for heavy programs.",
    "Consider upgrading your RAM."
]]
]


def chatbot_response(user_input):
    for pattern, responses in pairs:
        if re.search(pattern, user_input):
            return random.choice(responses)
    return "Sorry, I didn't understand that."


@app.route("/")
def home():
    return render_template("index.html")   # IMPORTANT FIX

@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json()
    user_input = data.get("message")
    return jsonify({"response": chatbot_response(user_input)})


if __name__ == "__main__":
    app.run(debug=True)