function sendMessage() {
    const input = document.getElementById("user-input");
    const message = input.value.trim();
    if (!message) return;

    hideWelcome();
    addMessage(message, "user");
    input.value = "";

    const typing = showTyping();

    fetch("/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message })
    })
    .then(r => r.json())
    .then(data => { typing.remove(); addMessage(data.response, "bot"); })
    .catch(() => { typing.remove(); addMessage("Unable to reach server. Please try again.", "bot"); });
}

function quickSend(btn) {
    document.getElementById("user-input").value = btn.textContent;
    sendMessage();
}

function addMessage(text, sender) {
    const box = document.getElementById("chat-box");
    const row = document.createElement("div");
    row.className = "message-row " + sender;

    const av = document.createElement("div");
    av.className = "av " + sender;
    av.textContent = sender === "bot" ? "AI" : "You";

    const bubble = document.createElement("div");
    bubble.className = "bubble " + sender;
    bubble.textContent = text;

    row.appendChild(av);
    row.appendChild(bubble);
    box.appendChild(row);
    box.scrollTop = box.scrollHeight;
}

function showTyping() {
    const box = document.getElementById("chat-box");
    const row = document.createElement("div");
    row.className = "typing-row";

    const av = document.createElement("div");
    av.className = "av bot";
    av.textContent = "AI";

    const bub = document.createElement("div");
    bub.className = "typing-bub";
    bub.innerHTML = '<div class="dot"></div><div class="dot"></div><div class="dot"></div>';

    row.appendChild(av);
    row.appendChild(bub);
    box.appendChild(row);
    box.scrollTop = box.scrollHeight;
    return row;
}

function hideWelcome() {
    const w = document.querySelector(".welcome-block");
    if (!w) return;
    w.style.transition = "opacity 0.2s, transform 0.2s";
    w.style.opacity = "0";
    w.style.transform = "scale(0.95)";
    setTimeout(() => w.remove(), 200);
}
