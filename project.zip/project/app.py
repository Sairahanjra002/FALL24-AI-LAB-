import os
from flask import Flask, render_template, request, jsonify
from groq import Groq
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)


client = Groq(api_key="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")
@app.route('/')
def index():
    """Renders the main dashboard."""
    return render_template('index.html')

@app.route('/generate', methods=['POST'])
def generate_code():
    """Handles the AI generation logic."""
    data = request.json
    user_prompt = data.get('prompt')
    language = data.get('language', 'General') # Pulls the mode from the dropdown

    if not user_prompt:
        return jsonify({"error": "Please enter a programming problem."}), 400

    try:
      
        completion = client.chat.completions.create(
            model="llama-3.3-70b-versatile", 
            messages=[
                {
                    "role": "system",
                    "content": (
                        f"You are an expert {language} Developer. "
                        f"Provide clean, efficient, and well-commented {language} code. "
                        "Include a brief explanation of how the logic works."
                    )
                },
                {
                    "role": "user",
                    "content": user_prompt
                }
            ],
            temperature=0.3, 
            max_tokens=2048,
            top_p=1,
            stream=False,
        )

     
        solution = completion.choices[0].message.content
        return jsonify({"solution": solution})

    except Exception as e:
        print(f"Error: {e}")
        return jsonify({"error": "Failed to connect to the AI engine. Check your API key."}), 500

if __name__ == '__main__':
   
    app.run(debug=True)