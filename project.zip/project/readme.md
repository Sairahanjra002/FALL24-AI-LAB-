# Project Documentation: AI Code Assistant
This document provides an overview and setup instructions for the AI Code Assistant, a Flask-based web application integrated with the Groq API for high-speed LLM inference.

## Overview
The AI Code Assistant is designed to help developers generate optimized code solutions and explanations across multiple programming languages. By leveraging the Llama 3 model via Groq's LPUs (Language Processing Units), the application provides near-instantaneous responses to complex programming queries.

## Core Features
Multi-Language Support: Specific modes for Python, JavaScript, C++, SQL, and Java.

### High-Speed Inference:
Integration with Groq API for low-latency code generation.

### Responsive UI:
A modern, glassmorphic web interface built with Bootstrap 5.

### Secure Configuration:
 Environment-based API key management.

### Technical Stack Backend:
 Python 3.x, Flask

### LLM Engine: 
Groq (Llama 3.3 / Llama 3.1)

### Frontend:
HTML5, CSS3 (Custom Glassmorphism), JavaScript (Fetch API)

### Configuration:
 Python-Dotenv

## Installation and Setup
### 1. Clone the Repository
Ensure you have Python installed, then navigate to your project directory.

### 2. Install Dependencies
Install the required Python packages using the provided requirements file:
pip install -r requirements.txt

### 3. Environment Configuration
Create a file named .env in the root directory. Add your Groq API key without spaces:
GROQ_API_KEY=your_api_key_here

### 4. Run the Application
Start the Flask development server:
python app.py

Access the application by navigating to http://127.0.0.1:5000 in your web browser.

## Project Structure 
Plaintext
CodeAssistant/
├── app.py              # Flask server and API integration logic
├── .env                # Private environment variables (API keys)
├── requirements.txt    # List of required Python libraries
└── templates/          # Directory for HTML files
    └── index.html      # Main application interface
### Usage
Select the desired programming language from the dropdown menu.

Input the programming problem or logic requirement in the text area.

Click Compile Solution to receive the AI-generated code and technical explanation.

### Disclaimer
This tool is intended for educational and development assistance. Always verify the generated code for security and performance before deploying in a production environment.