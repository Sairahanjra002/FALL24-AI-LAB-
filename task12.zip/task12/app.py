
from flask import Flask, render_template, request, jsonify
import pandas as pd
import numpy as np
import faiss
import re
from sentence_transformers import SentenceTransformer

app = Flask(__name__)


model = None
index = None
df = None
is_ready = False

def clean_text(text):
    text = str(text).lower()
    text = re.sub(r'[^a-zA-Z0-9\s]', '', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text

def load_data():
    global model, index, df, is_ready
    print("Loading dataset...")
    df = pd.read_csv(
        "https://huggingface.co/datasets/rojagtap/ubuntu_dialogs_corpus/resolve/main/train.csv"
    )
    df = df.sample(50000, random_state=42).reset_index(drop=True)
    df["Context"]   = df["Context"].apply(clean_text)
    df["Utterance"] = df["Utterance"].apply(clean_text)
    df["text"]      = df["Context"] + " " + df["Utterance"]

    print("Loading sentence-transformer model...")
    model = SentenceTransformer('all-MiniLM-L6-v2')

    print("Encoding embeddings...")
    embeddings = model.encode(df["text"].tolist(), show_progress_bar=True)

    dimension = embeddings.shape[1]
    index = faiss.IndexFlatL2(dimension)
    index.add(np.array(embeddings))

    is_ready = True
    print("System ready!")

def get_solution(query, k=3):
    query_clean   = clean_text(query)
    query_vector  = model.encode([query_clean])
    distances, indices = index.search(query_vector, k)
    results = []
    for idx, dist in zip(indices[0], distances[0]):
        results.append({
            "problem":  df.iloc[idx]["Context"],
            "solution": df.iloc[idx]["Utterance"],
            "score":    float(dist)
        })
    return results


@app.route("/")
def home():
    return render_template("index.html")

@app.route("/search", methods=["POST"])
def search():
    if not is_ready:
        return jsonify({"error": "System is still loading. Please wait."}), 503
    data  = request.get_json()
    query = data.get("query", "").strip()
    k     = int(data.get("k", 3))
    if not query:
        return jsonify({"error": "Query cannot be empty."}), 400
    results = get_solution(query, k=k)
    return jsonify({"results": results, "query": query})

@app.route("/status")
def status():
    return jsonify({"ready": is_ready})


if __name__ == "__main__":
    import threading
    t = threading.Thread(target=load_data, daemon=True)
    t.start()
    app.run(debug=True, use_reloader=False)
