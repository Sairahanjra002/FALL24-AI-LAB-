
const input       = document.getElementById('query-input');
const btn         = document.getElementById('search-btn');
const kSelect     = document.getElementById('k-select');
const statusBadge = document.getElementById('status-badge');
const resultsSection = document.getElementById('results-section');
const resultsGrid    = document.getElementById('results-grid');
const resultsQuery   = document.getElementById('results-query');
const loadingState   = document.getElementById('loading-state');
const errorMsg       = document.getElementById('error-msg');
const cardTemplate   = document.getElementById('card-template');


let systemReady = false;

async function pollStatus() {
  try {
    const res  = await fetch('/status');
    const data = await res.json();
    if (data.ready) {
      systemReady = true;
      statusBadge.className = 'badge ready';
      statusBadge.innerHTML = '<span class="dot"></span> Ready';
      btn.disabled = false;
    } else {
      setTimeout(pollStatus, 2000);
    }
  } catch {
    setTimeout(pollStatus, 3000);
  }
}
pollStatus();

async function doSearch() {
  const query = input.value.trim();
  if (!query || !systemReady) return;

  // Reset UI
  hideError();
  resultsSection.classList.add('hidden');
  loadingState.classList.remove('hidden');
  btn.disabled = true;

  try {
    const res  = await fetch('/search', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query, k: parseInt(kSelect.value) })
    });
    const data = await res.json();

    if (!res.ok) {
      showError(data.error || 'Something went wrong.');
      return;
    }

    renderResults(data.results, data.query);

  } catch (err) {
    showError('Network error — is the Flask server running?');
  } finally {
    loadingState.classList.add('hidden');
    btn.disabled = false;
  }
}


function renderResults(results, query) {
  resultsGrid.innerHTML = '';
  resultsQuery.textContent = `"${query}"`;

  results.forEach((r, i) => {
    const clone = cardTemplate.content.cloneNode(true);
    clone.querySelector('.card-num').textContent      = String(i + 1).padStart(2, '0');
    clone.querySelector('.card-problem').textContent  = r.problem  || '—';
    clone.querySelector('.card-solution').textContent = r.solution || '—';
    clone.querySelector('.card-score').textContent    = `L2 ${r.score.toFixed(2)}`;
    resultsGrid.appendChild(clone);
  });

  resultsSection.classList.remove('hidden');


  resultsSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function showError(msg) {
  errorMsg.textContent = msg;
  errorMsg.classList.remove('hidden');
}
function hideError() {
  errorMsg.classList.add('hidden');
}


btn.addEventListener('click', doSearch);
input.addEventListener('keydown', e => {
  if (e.key === 'Enter') doSearch();
});
